#!/usr/bin/python
OSCAD_HOME="/home/hardik/OSCAD"
