#!/usr/bin/python
OSCAD_HOME="C:/OSCAD/OSCAD"
